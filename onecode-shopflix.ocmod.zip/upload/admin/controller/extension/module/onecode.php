<?php

class ControllerExtensionModuleOnecode extends Controller
{
}