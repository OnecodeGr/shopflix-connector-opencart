<?php

use GuzzleHttp\Client;
use Onecode\Shopflix\Helper;
use Onecode\ShopFlixConnector\Library\Connector;
use Onecode\ShopFlixConnector\Library\Interfaces\OrderInterface;

require_once DIR_SYSTEM . 'library/onecode/vendor/autoload.php';
require_once DIR_SYSTEM . 'helper/onecode/shopflix/model/ReturnOrder.php';

/**
 * @property-read \DB $db
 * @property-read \Loader $load
 * @property-read \Config $config
 * @property-read \Language $language
 * @property-read \Request $request
 * @property-read \Session $session
 * @property-read \Cart\Cart $cart
 * @property-read \ModelSaleOrder $model_sale_order
 * @property-read \ModelUserApi $model_user_api
 * @property-read \Cart\User $user
 * @property-read \ModelSettingExtension $model_setting_extension
 * @property-read \ModelSettingStore $model_setting_store
 * @property-read \ModelExtensionModuleOnecodeShopflixConfig $model_extension_module_onecode_shopflix_config
 * @property-read \ModelExtensionModuleOnecodeShopflixConfig $config_model
 */
class ModelExtensionModuleOnecodeShopflixReturnOrder extends Helper\Model\ReturnOrder
{
    public function __construct($registry)
    {
        parent::__construct($registry);
        $this->load->model('setting/store');
        $this->load->model('setting/extension');
        $this->load->model('extension/module/onecode/shopflix/config');
        $this->config_model = new ModelExtensionModuleOnecodeShopflixConfig($registry);
        if ($this->config_model->apiUrl() != '')
        {
            $this->connector = new Connector(
                $this->config_model->apiUsername(),
                $this->config_model->apiPassword(),
                $this->config_model->apiUrl()
            );
        }
    }

    protected function createOrderTable()
    {
        $this->db->query(sprintf("CREATE TABLE IF NOT EXISTS %s (
 `id` INT UNSIGNED AUTO_INCREMENT NOT NULL,
 `order_id` int not null UNSIGNED,
 `vendor_parent_id` varchar(255),
 `reference_id` varchar(255),
 `state` varchar(255),
 `status` varchar(255),
 `sub_total` decimal(10,3),
 `total_paid` decimal(10,3),
 `customer_email` varchar(255),
 `customer_firstname` varchar(255),
 `customer_lastname` varchar(255),
 `customer_remote_ip` varchar(255),
 `customer_note` varchar(255),
 `created_at` timestamp not null,
 `update_at` timestamp default current_timestamp not null,
 PRIMARY KEY (`id`),
 UNIQUE INDEX (`reference_id`)
 INDEX (`order_id`),
 FOREIGN KEY (order_id) REFERENCES %s(id) ON DELETE CASCADE ON UPDATE CASCADE
)", self::getTableName(), self::getOrderTableName()));
    }

    protected function createOrderAddressTable()
    {
        $this->db->query(sprintf("CREATE TABLE IF NOT EXISTS %s (
 `id` INT UNSIGNED AUTO_INCREMENT NOT NULL,
 `order_id` INT UNSIGNED NOT NULL,
 `firstname` varchar(255),
 `lastname` varchar(255),
 `postcode` varchar(255),
 `telephone` varchar(255),
 `street` varchar(255),
 `type` varchar(255),
 `city` varchar(255),
 `email` varchar(255),
 `country_id` varchar(255),
 PRIMARY KEY (`id`),
 UNIQUE INDEX (`order_id`,`type`),
    FOREIGN KEY (order_id) REFERENCES %s(id) ON DELETE CASCADE ON UPDATE CASCADE
)", self::getAddressTableName(), self::getTableName()));
    }

    protected function createOrderItemTable()
    {
        $this->db->query(sprintf("CREATE TABLE IF NOT EXISTS %s (
 `id` INT UNSIGNED AUTO_INCREMENT NOT NULL,
 `order_id` INT UNSIGNED NOT NULL,
 `sku` varchar(255),
 `price` decimal(10,3),
 `quantity` SMALLINT UNSIGNED,
 `reason` TEXT,
 PRIMARY KEY (`id`),
    FOREIGN KEY (order_id) REFERENCES %s(id) ON DELETE CASCADE ON UPDATE CASCADE
)", self::getItemTableName(), self::getTableName()));
    }

    public function install()
    {
        $this->createOrderTable();
        $this->createOrderAddressTable();
        $this->createOrderItemTable();
        $this->update_character_collection();
    }

    public function uninstall()
    {
        $this->db->query(sprintf('DROP TABLE IF EXISTS %s', self::getItemTableName()));
        $this->db->query(sprintf('DROP TABLE IF EXISTS %s', self::getAddressTableName()));
        $this->db->query(sprintf('DROP TABLE IF EXISTS %s', self::getTableName()));
    }

    public function update_character_collection()
    {
        $this->db->query(sprintf('alter table %s convert to character set utf8 collate utf8_general_ci;', self::getTableName()));
        $this->db->query(sprintf('alter table %s convert to character set utf8 collate utf8_general_ci;', self::getItemTableName()));
        $this->db->query(sprintf('alter table %s convert to character set utf8 collate utf8_general_ci;', self::getAddressTableName()));
    }

    public function getOrderById($order_id): array
    {
        $sql = "SELECT * FROM " . self::getTableName() . " WHERE id = " . intval($order_id) . " LIMIT 1;";
        $query = $this->db->query($sql);
        return count($query->rows) ? $query->row : [];
    }
}