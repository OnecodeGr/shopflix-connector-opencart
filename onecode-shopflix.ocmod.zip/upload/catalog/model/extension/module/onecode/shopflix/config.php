<?php

use Onecode\Shopflix\Helper;

require_once DIR_SYSTEM . 'helper/onecode/shopflix/model/Configuration.php';

class ModelExtensionModuleOnecodeShopflixConfig extends Helper\Model\Configuration
{
}