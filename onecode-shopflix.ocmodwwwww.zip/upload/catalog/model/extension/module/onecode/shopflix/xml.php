<?php

use Onecode\Shopflix\Helper;

require_once DIR_SYSTEM . 'helper/onecode/shopflix/model/config/Xml.php';

class ModelExtensionModuleOnecodeShopflixXml extends Helper\Model\Config\Xml
{
}